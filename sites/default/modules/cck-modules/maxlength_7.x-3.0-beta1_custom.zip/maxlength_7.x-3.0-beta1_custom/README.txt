This module allows you to set a maximum length for any text field on any form.

Customized module according to -> http://drupal.org/node/1341970